# UTN-SEC-INFO



## Proyecto con fines unicamente academicos

## Reglas de convivencias
* Cada equipo debe tener su propia rama de trabajo.
* Nunca se podra trabajar directamente sobre la rama principal.
* Leer los README de cada seccion.