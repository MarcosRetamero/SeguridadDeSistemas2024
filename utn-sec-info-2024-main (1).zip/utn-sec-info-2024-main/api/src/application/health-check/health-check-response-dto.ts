export class HealthCheckResponseDto {
    message: string;

    constructor(message: string) {
        this.message = message;
    }
}