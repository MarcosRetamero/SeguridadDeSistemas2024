import { initFirebaseAdmin } from "./initFirebaseAdmin";
import { initFirebaseClient } from "./initFirebaseClient";

export {
    initFirebaseAdmin,
    initFirebaseClient
}