# Pequeña API utilizando, node, express y typescript.

## Instalar la aplicacion
```
npm install
```

## Iniciar la api
```
npm run dev
```