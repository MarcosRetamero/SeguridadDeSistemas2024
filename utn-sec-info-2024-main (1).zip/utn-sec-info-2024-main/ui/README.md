# No es mas que una pequeña UI utilizando VUE 3, Vuetify y typescript.

1- Instalar la aplicacion
    npm install

2- Iniciar la api
    npm run dev


Vuetify: https://vuetifyjs.com/en/components/all/