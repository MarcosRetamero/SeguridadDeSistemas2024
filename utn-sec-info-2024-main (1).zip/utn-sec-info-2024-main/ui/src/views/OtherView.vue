<template>
  <h1>{{ message }}</h1>
</template>

<script lang="ts" setup>
const message = "Other View";

</script>
