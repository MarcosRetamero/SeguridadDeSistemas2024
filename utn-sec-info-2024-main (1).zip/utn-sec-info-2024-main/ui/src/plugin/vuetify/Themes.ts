export const Themes = {
    Light: 'light',
    Dark: 'dark'
}